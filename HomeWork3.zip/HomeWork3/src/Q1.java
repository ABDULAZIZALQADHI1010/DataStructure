import java.util.Arrays;

public class Q1 {
    public static void main(String[] args) {
        int []arr={3,6,8,2,0,1};
        int []arr2=arr.clone();
        System.out.println("arr = "+ Arrays.toString(arr));
        System.out.println("arr2 = "+ Arrays.toString(arr2));
    }
}